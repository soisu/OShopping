class Order_Product {
  int? _id;
  int? _odid;
  int? _pid;
  double? _price;

  Order_Product(
    this._id,
    this._odid,
    this._pid,
    this._price
    );
}