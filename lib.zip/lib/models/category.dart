class Category {
  int? _cid;
  String? _cname;
  String? _description;

  Category(
    this._cid,
    this._cname,
    this._description
    );
}