class ShippingInfo {
  int? _shipid;
  String? _shiptype;
  String? _shipAddress;

  ShippingInfo(
    this._shipid,
    this._shiptype,
    this._shipAddress
    );
}